#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 3/5/23 5:41 PM

@author: alejandrobertolet
"""

from mgm import *